// $(function(){
// $(".navbar .nav ul li").click(function(){
// $(this).addClass("active").siblings().removeClass("active");
// });
// $("section.opacity .image .rgba").click(function(){
//     $(this).slideUp(2000);

// });

// });
$(function(){
    $("section.navbar1 ul li").click(function(){
    $(this).addClass("active").siblings().removeClass("active");
    });
    
    });