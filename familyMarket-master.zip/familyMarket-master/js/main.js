$(document).ready(function(){
    $(".twsel").hide();
    $(".push").click(function(){
        $(".twsel").show().siblings(".a").hide();

    
    } );
    $(".twsel1").hide();
    $(".del").click(function(){
        $(".twsel1").show().siblings(".a").hide();

    
    } );
    $(".twsel2").hide();
    $(".qustion").click(function(){
        $(".twsel2").show().siblings(".a").hide();

    
    } );
    $(".twsel3").hide();
    $(".tel").click(function(){
        $(".twsel3").show().siblings(".a").hide();

    
    } );
    $(".we").hide();
    $(".qul").click(function(){
        $(".we").show().siblings(".a").hide();

    
    } );
    $(".we1").hide();
    $(".gift").click(function(){
        $(".we1").show().siblings(".a").hide();

    
    } );
    $(".we2").hide();
    $(".gift").click(function(){
        $(".we2").show().siblings(".a").hide();

    
    } );


    $(".offer").hide();
    $(".laban").click(function(){
        $(".offer").toggle().siblings(".d").hide();


    });
    $(".offe").hide();
    $(".buscit").click(function(){
        $(".offe").toggle().siblings(".d").hide();


    });
    $(".labn").hide();
    $(".boog").click(function(){
        $(".labn").toggle().siblings(".d").hide();


    });
    $(".electron").hide();
    $(".electronic").click(function(){
        $(".electron").toggle().siblings(".d").hide();


    });
    $(".all").hide();
    $(".al").click(function(){
        $(".all").toggle().siblings(".d").hide();


    });
    $(".cllean").hide();
    $(".cleans").click(function(){
        $(".cllean").toggle().siblings(".d").hide();


    });
    $(".offers .baskot").hide();
    $(".drinks").click(function(){
        $(".offers .baskot").toggle().siblings(".d").hide();


    });
    $(".offers .bb").hide();
    $(".cons").click(function(){
        $(".offers .bb").toggle().siblings(".d").hide();


    });
    $(".offers .bb").hide();
    $(".buscit").click(function(){
        $(".offers .bb").toggle().siblings(".d").hide();


    });
   
  


});